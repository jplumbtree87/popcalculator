﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PopCalculator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        uint organism;
        float increase;
        uint days;
        const string DIRNAME = "PROG8010";
        const string FILENAME = "log.txt";

        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                lbDisplay.Items.Clear();
                organism = uint.Parse(tbOrganism.Text);
                days = uint.Parse(tbDays.Text);
                increase = float.Parse(tbIncrease.Text);
                for (int i = 1; i <= days; i++)
                {
                    organism = (uint)(organism * (1 + increase / 100));
                    lbDisplay.Items.Add("Day " + i.ToString() + ": " + organism.ToString());
                }
            }
            catch
            {
                MessageBox.Show("Please enter acceptable values");
            }

        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            string path = System.Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);

            string fullpath = System.IO.Path.Combine(path, DIRNAME);
            Directory.CreateDirectory(fullpath);

            string fullname = System.IO.Path.Combine(fullpath, FILENAME);
            StreamWriter sw = File.AppendText(fullname);

            for(int i = 0; i < lbDisplay.Items.Count; i++)
            {
                sw.Write(lbDisplay.Items.GetItemAt(i));
                sw.WriteLine(" ");
            }
            sw.WriteLine(" ");
            sw.Close();
        }
    }
}
